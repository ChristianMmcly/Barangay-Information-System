<!DOCTYPE html>
<html>
<head>
    <title>BMIS</title>
    <script language="javascript">
        window.location.href = "dashboard.php"
    </script>
</head>

<body>
    Go to <a href="dashboard.php">dashboard.php</a>
</body>

</html>